
import UserProfile from "./UserProfile/UserProfile";
import './App.css';

const userDetailsList = [
    {
        uniqueNo: 1,
        imageUrl: 'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
        name: 'Esther Howard',
        role: 'Software Developer',
    },
    {
        uniqueNo: 2,
        imageUrl: 'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
        name: 'Jane Doe',
        role: 'Product Manager',
    },
    {
        uniqueNo: 3,
        imageUrl: 'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
        name: 'John Smith',
        role: 'UX Designer',
    },
    {
        uniqueNo: 4,
        imageUrl: 'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
        name: 'Alice Johnson',
        role: 'QA Engineer',
    }
];

const App = () => {
    return (
        <div className="list-container">
            <h1 className="title">User Details</h1>
            <ul>
                {userDetailsList.map(eachItem => (
                    <UserProfile userDetails={eachItem} key={eachItem.uniqueNo} />
                ))}
            </ul>
        </div>
    );
};

export default App;
